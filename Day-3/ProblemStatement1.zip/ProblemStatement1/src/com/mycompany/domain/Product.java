package com.mycompany.domain;

public class Product {
	String ProductId;
	String ProductName;
	int ProductPrice;
	
	public Product(){
		
	}
	public Product(String productId, String productName, int productPrice) {
		ProductId = productId;
		ProductName = productName;
		ProductPrice = productPrice;
	}
	public String getProductId() {
		return ProductId;
	}
	public void setProductId(String productId) {
		ProductId = productId;
	}
	public String getProductName() {
		return ProductName;
	}
	public void setProductName(String productName) {
		ProductName = productName;
	}
	public int getProductPrice() {
		return ProductPrice;
	}
	public void setProductPrice(int productPrice) {
		ProductPrice = productPrice;
	}
	@Override
	public String toString() {
		return "Product [ProductId=" + ProductId + ", ProductName=" + ProductName + ", ProductPrice=" + ProductPrice
				+ "]";
	}
	
	
}
