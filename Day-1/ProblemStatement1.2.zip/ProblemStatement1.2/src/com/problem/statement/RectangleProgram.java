package com.problem.statement;

import java.util.Scanner;

public class RectangleProgram {
	private int length;
	private int breadth;
	private int area;
	public RectangleProgram()
	{		
		length = 0;
		breadth = 0;
	}
	
	void input() {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter Length of the rectangle: ");
		length = scan.nextInt();
		System.out.println("Enter Breadth of the rectangle ");
		breadth = scan.nextInt();
	}
	//To Calculate Area
	void calculate() {
		area=length*breadth;
	}
	//To Display Area
	void display() {
		System.out.println("Area Of a Rectangle=" +area);
	}
	public static void main(String[] args) {
		RectangleProgram obj1=new RectangleProgram();
		obj1.input();
		obj1.calculate();
		obj1.display();
		System.out.println("=========================================");
		RectangleProgram obj2=new RectangleProgram();
		obj2.input();
		obj2.calculate();
		obj2.display();
		System.out.println("=========================================");
		RectangleProgram obj3=new RectangleProgram();
		obj3.input();
		obj3.calculate();
		obj3.display();
		System.out.println("=========================================");
		RectangleProgram obj4=new RectangleProgram();
		obj4.input();
		obj4.calculate();
		obj4.display();
		System.out.println("=========================================");
		RectangleProgram obj5=new RectangleProgram();
		obj5.input();
		obj5.calculate();
		obj5.display();
	}	
	

}
