package com.problem.statement;

import java.util.ArrayList;

public class Student {
	public static void main(String[] args) {
		ArrayList<String> names= new ArrayList<String>();
		names.add("sairam");
		names.add("reddy");
		names.add("sridher");
		names.add("Lilly");
		
		System.out.println("Name of the students: "+" "+names);
		
		System.out.println("Check student name exits or not: "+" "+names.contains("sairam"));
	}

}
