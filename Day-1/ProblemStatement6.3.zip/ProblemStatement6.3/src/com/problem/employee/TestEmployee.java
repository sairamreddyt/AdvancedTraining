package com.problem.employee;

public class TestEmployee {

	public static void main(String[] args) {
        LinkedList<Employee> linkedList = new LinkedList<Employee>(); 
        // creation of Linked List
        
        linkedList.insertFirst(new Employee(41, "sai","kadapa"));
        linkedList.insertFirst(new Employee(43, "sridher","b2 block"));
        linkedList.insertFirst(new Employee(30, "lilly","c3 block"));
        linkedList.displayLinkedList();
  }
}
