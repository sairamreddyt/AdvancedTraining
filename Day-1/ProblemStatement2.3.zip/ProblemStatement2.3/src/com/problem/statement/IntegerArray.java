package com.problem.statement;

import java.util.Arrays;

public class IntegerArray {
	
	public static void main(String[] args) {
		int arr[] = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
		 System.out.println("Elements of the array are: "+Arrays.toString(arr));
		int sum=0;
		int smallest = Integer.MAX_VALUE;
		 for (int i = 0; i < arr.length; i++) {
	         sum += arr[i];
	         
		 }
		 System.out.println("Sum of the elements of the array :"+sum);
		 arr[arr.length-3]=sum;
		 System.out.println("array inserting in 15 index is: "+ arr[arr.length-3]);
		 System.out.println("Elements of the array are: "+Arrays.toString(arr));
		 double average = sum/arr.length;
		 System.out.println("Average of an array is:"+average);
		 arr[arr.length-2]=(int) average;
		 System.out.println("array inserting in 16 index is: "+ arr[arr.length-2]);
		 System.out.println("Elements of the array are: "+Arrays.toString(arr));
		 int index=0;
		 while(index<arr.length) {
	            //check if smallest is greater than element
	            if(smallest>arr[index]) {
	                //update smallest
	                smallest=arr[index];
	            }
	            index++;
	        }
		 System.out.println("The smallest number is : "+ smallest);
		 System.out.println("array inserting in 17 index is: "+ arr[arr.length-1]);
		 System.out.println("Elements of the array are: "+Arrays.toString(arr));
	}

}
