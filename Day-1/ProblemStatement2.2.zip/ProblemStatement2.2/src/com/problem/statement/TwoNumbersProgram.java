package com.problem.statement;

import java.util.Scanner;

public class TwoNumbersProgram {
	public static void main(String[] args) {
		int n;
		int num1,num2;	
		System.out.println("Enter How Many numbers you want in the sequence: ");
		Scanner scan=new Scanner(System.in);
		n=scan.nextInt();
		System.out.println("Enter two numbers num1 and num2 ");
		num1=scan.nextInt();
		num2=scan.nextInt();
		System.out.println("fibonacci series till"+" "+ n +" "+ "numbers:");
		
		int i=1;
		while(i<=n) {
			System.out.println(num1+" ");
			int next=num1+num2;
			num1=num2;
			num2=next;
			
			i++;
		}		
		
		
	}

}
