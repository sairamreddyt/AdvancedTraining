package com.problem.statement;

import java.util.Hashtable;
import java.util.Scanner;

public class Product {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Hashtable<String, String> ht=new Hashtable<String, String>();
		System.out.println("Enter Product Id and Product Name");
		for(int i=0;i<4;i++) {
			ht.put(sc.next(), sc.next());
		}
		System.out.println("The Product list is: "+" "+ht);
		System.out.println("Enter the Product id to be removed ");
		String id=sc.next();
		ht.remove(id);
		System.out.println("Product removed Successfully");
		System.out.println("The Product list is: "+" "+ht);
		System.out.println("Enter Product id to searched");
		String sid=sc.next();
		if(ht.containsKey(sid))
		{
			System.out.println(ht.get(sid));
		}
		else
		{
			System.out.println("Product doesn't exits");
		}
	}

}
