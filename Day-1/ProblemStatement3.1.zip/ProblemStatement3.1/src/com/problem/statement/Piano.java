package com.problem.statement;

public class Piano extends Instrument {

	@Override
	public void play() {
		System.out.println("Piano is playing tan tan tan tan");
	}

}
