package com.problem.statement;

public class BankAccount {
	int account_number;
	String name;
	String account_type;
	double balance;
	public int getAccount_number() {
		return account_number;
	}
	public void setAccount_number(int account_number) {
		this.account_number = account_number;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAccount_type() {
		return account_type;
	}
	public void setAccount_type(String account_type) {
		this.account_type = account_type;
	}
	public double getBalance() {
		if(balance<1000) {
			try {
				throw new NumberFormatException();
			} catch (Exception e) {
				System.out.println("Your Balance is low"+balance);
			}
		}
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public BankAccount(int account_number, String name, String account_type, double balance) {
		this.account_number = 6666;
		this.name = "sai";
		this.account_type = "Saving";
		this.balance = 66660;
	}
	public BankAccount() {
		// TODO Auto-generated constructor stub
	}
	public void deposit(double amount) {
		if(amount<0) {
			try {
				throw new NumberFormatException();
			} catch (Exception e) {
				System.out.println("Negative amount will be added");
			}
		}
		else {
			balance=getBalance()+amount;
			System.out.println("current balance is: "+balance);
		}
	}
	public void withdraw(double amount) {
		if(amount<1000) {
			try {
				throw new NumberFormatException();
			} catch (Exception e) {
				System.out.println("You canot withdraw amount because insufficient balance");
			}
			
		}
		else {
			balance=getBalance()-amount;
			System.out.println("current balance is: "+balance);
		}
	}
	public void display()
     {
         System.out.println("Balance is: "+getBalance());   
     }
   public static void main(String[] args) {
	BankAccount b=new BankAccount();
	b.deposit(6000);
	b.display();
	b.withdraw(3000);
	b.display();
	b.withdraw(1000);
	b.getBalance();
	b.display();
}

}
