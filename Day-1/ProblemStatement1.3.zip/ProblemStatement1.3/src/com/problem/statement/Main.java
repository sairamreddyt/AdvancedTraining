package com.problem.statement;

public class Main {
	
	public void createbook() {
		Book b[]=new Book[2];
		b[0]=new Book("Java Programming",350.50);
		b[1]=new Book("Let Us C",200.00);
		for(int i=0;i<b.length;i++)
		{
			b[i].Display();
			System.out.println(" ");
		}
	}
	public void ShowBook() {
		createbook();
	}
	public static void main(String[] args) {
		Main m=new Main();
		m.ShowBook();
	}
		

}
