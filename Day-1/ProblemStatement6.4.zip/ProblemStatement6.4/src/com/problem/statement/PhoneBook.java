package com.problem.statement;

import java.util.Scanner;

public class PhoneBook {
	public static String helpmsg="Press: -A Add Contact -S Search Contact -Q Exit";
	public static void main(String[] args) {
		System.out.println("**********Welcome to Phone Book**********");
		Scanner scan=new Scanner(System.in);
		for(;;) {
			System.out.print("Main Menu "+helpmsg+"\n:");
			String s=scan.next().trim();

			if(s.equalsIgnoreCase("A")) {
				System.out.println("Type in contact details in the form of name,phone");
			}
			else if(s.equalsIgnoreCase("S"))
			{
				System.out.println("Enter name to search contact");
			}
			else if(s.equalsIgnoreCase("Q"))
			{
				System.out.println("Bye User...");
			    System.exit(0);
			}
			else {
				System.out.println("Please enter correct data...");
			}
		}
	}	

}
