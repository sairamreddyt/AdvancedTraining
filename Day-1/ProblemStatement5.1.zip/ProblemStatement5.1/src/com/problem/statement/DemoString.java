package com.problem.statement;

public class DemoString {
	public static void main(String[] args) {
		String txt = "JAVA is Simple";
		//converting into upper case
		System.out.println("Converting into upper case :"+" "+txt.toUpperCase());
		//converting into lower case
		System.out.println("Converting into lower case :"+" "+txt.toLowerCase());
		
		String[] words =txt.split("\\s");
		for(String w:words) {
			System.out.println(w.charAt(0));
			System.out.println("");
		}
		
		String[] word1=txt.split("\\s");
		for(String w:word1) {
			System.out.println(w);
		}
		System.out.println(" ");
		//String Builder
		StringBuilder word2=new StringBuilder();
	    word2.append(txt);
	    word2.reverse();
	    System.out.println(word2);
	    //length of the string
	    System.out.println("Length of the string is: "+" "+txt.length());
	}

}
