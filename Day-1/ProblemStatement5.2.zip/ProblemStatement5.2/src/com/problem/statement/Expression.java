package com.problem.statement;

import java.util.Scanner;

public class Expression {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Please enter expression: ");
		String n=scan.nextLine();
		String[] s=n.split("\\s");
		
		for(String a:s) {
			System.out.println(a);
		}
	}
// please provide expression like this way 20 + 20 - (10 / 20 )
	
// not provide like this 20+20-(10/20)
}
