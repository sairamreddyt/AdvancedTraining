package com.problem.coin;

import java.util.Scanner;
import java.util.Vector;

public class CoinChange {
	static int deno[] = {1,2,5,10,20,50,100,500,2000};
		    static int n = deno.length;
		  
		    static void findMin(int v)
		    {
		   	        Vector<Integer> a = new Vector<>();
		  
		       	        for (int i = n - 1; i >= 0; i--)
		        {
		           
		            while (v >= deno[i]) 
		            {
		                v -= deno[i];
		                a.add(deno[i]);
		            }
		        }		  
		        
		        for (int i = 0; i < a.size(); i++)
		        {
		            System.out.print(" " + a.elementAt(i));
		        }
		        System.out.println("\n The minimum number of coins is "+a.size());
		    }	  
		   
		    public static void main(String[] args) 
		    {
		    	 Scanner scanner=new Scanner(System.in);
		    	   System.out.println("Enter the Number");
		    	   int n=scanner.nextInt();
		            	   
		        System.out.print(" Following is minimal number " +"of change for " + n + ": ");
		        findMin(n);
		    }
}
