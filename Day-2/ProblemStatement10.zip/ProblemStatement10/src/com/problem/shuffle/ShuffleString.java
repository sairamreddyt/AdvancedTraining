package com.problem.shuffle;

import java.util.Scanner;

public class ShuffleString {
	public static boolean isInterleaving(String a,String b,String c)
	{
		if(a.length()==0 && b.length()==0 && c.length()==0)
		{
			return true;
		}
		if(c.length()==0)
		{
			return false;
		}
		if (a.length() != 0 && c.charAt(0) == a.charAt(0))
		{
            return isInterleaving(a.substring(1), b, c.substring(1));
        }
        if (b.length() != 0 && c.charAt(0) == b.charAt(0))
        {
            return isInterleaving(a, b.substring(1), c.substring(1));
        }
 
        return false;
    }
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter First String: ");
		String a=scan.nextLine();
		System.out.println("Enter Second String: ");
		String b=scan.nextLine();
		System.out.println("Enter Third String: ");
		String c=scan.nextLine();
		
		if(isInterleaving(a, b, c))
		{
			System.out.println("Interleaving");
		}
		else
		{
			System.out.println("Given String not Interleaving a and b");
		}
	}


}
